<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Recover_password extends CI_Controller {

	public function index()
	{
		$this->load->view('admin/auth/forgot-password');
	}
	public function password_reset()
	{
			$this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
			if ($this->form_validation->run() == FALSE)
			{
				$this->load->view('admin/auth/forgot-password');
			}
			else
			{
				$email = trim($this->security->xss_clean($this->input->post('email')));
				$this->load->model('admin/Users', 'Users');
				$email_exist_result = $this->Users->email_exists($email);
				if($email_exist_result)
				{
					$this->send_password_reset_email($email, $email_exist_result);
				}else{
					$this->session->set_flashdata("email_message","This email doesn't exist in our database");
					$this->load->view('admin/auth/forgot-password');
				}
			}
	}
	public function reset_form($email, $email_code)
	{
		if(isset($email, $email_code))
		{
			$email = trim($email);
			$email_hash = sha1($email.$email_code);
			$this->load->model('admin/Users', 'Users');
			$verified = $this->Users->verify_reset_password_code($email, $email_code);
			if($verified)
			{
				$data = array(
					'email_hash'=>$email_hash,
					'email_code'=>$email_code,
					'email'=>$email
				);
				$this->load->view('admin/auth/password-reset-form', $data);
			}else{
				$this->load->view('admin/auth/forgot-password',array('error'=>'There was a problem with a link, Please try to reset it again', 'email'=>$email));
			}
		}else{
			$this->load->view('admin/auth/forgot-password',array('error'=>'There was a problem with a link, Please try to reset it again', 'email'=>$email));
		}
	}
	public function send_password_reset_email($email, $firstname)
	{
		$this->load->library('email');
		$email_code = md5($this->config->item('salt').$firstname);
		$this->email->set_mailtype('html');
		$this->email->from($this->config->item('bot_email'), 'Admin');
		$this->email->to($email);
		$this->email->subject('Password Reset Request');
		$message = '<!DOCTYPE html>
					<html lang="en">
					<head>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, initial-scale=1.0">
						<title>Password</title>
					</head>
					<body>
						<h3 style="text-align: center; color: white; background-color: green; padding: 16px 0;">Password Recovery Request</h3>';
		$message .='<p>Dear <strong>'.$firstname.'</strong>,</p>';
		$message .='<p>A password reset request has been made by you. Please <a href="'.base_url().'reset/'.$email.'/'.$email_code.'">click here</a> to reset your password.</p>';
		$message .='<p>If you didn\'t make this request, plese ignore this message</p>';
		$message .='<p><strong>Team</strong></p>';
		$message.='<h3 style="text-align: center; color: white; background-color: green; padding: 16px 0;">Thank You</h3></body>
		</html>';
		$this->email->message($message);
		//Send mail
		if($this->email->send())
			$this->session->set_flashdata("email_message","password reset link has been sent to your email, Please check your spam/junk folder also if you don't receive link.");
		else
			$this->session->set_flashdata("email_message","You have encountered an error");
		$this->load->view('admin/auth/forgot-password');
	}
	public function password_update()
	{
		if(!isset($_POST['email'], $_POST['email_hash']) || $_POST['email_hash'] != sha1($_POST['email'].$_POST['email_code']))
		{
			die('Error Updating Password');
		}
		$config = array(
			array(
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'valid_email|required|trim',
				'errors' => array(
					'required' => 'You must provide an %s.',
					'valid_email'=>'Your %s seems invalid'
				),
			),
			array(
				'field' => 'email_hash',
				'label' => 'Email Hash',
				'rules' => 'required|trim',
				'errors' => array(
					'required' => 'You must provide an %s.'
				),
			),
			array(
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required|trim|min_length[6]|max_length[15]',
			),
			array(
				'field' => 'password_conf',
				'label' => 'Confirm Password',
				'rules' => 'required|trim|min_length[6]|max_length[15]|matches[password]',
			)
		);
		$this->form_validation->set_rules($config);
		if ($this->form_validation->run() == FALSE)
		{
			$email_hash = $_POST['email_hash'];
			$email_code = $_POST['email_code'];
			$email = $_POST['email'];

			$data = array(
				'email_hash'=>$email_hash,
				'email_code'=>$email_code,
				'email'=>$email
			);
			$this->load->view('admin/auth/password-reset-form', $data);
		}
		else {
			$this->load->model('admin/Users', 'Users');
			$result = $this->Users->update_password();
			if($result)
			{
				$this->session->set_flashdata('pass_update_success','Your password has been reset. Login here!');
				redirect('login');
			}else{
				$this->load->view('admin/auth/password-reset-form', array('error'=>'Problem updating your password. Please contact '.$this->config->item('admin_email')));
			}
		}
	}
}

