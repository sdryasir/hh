<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?php echo $title;?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?php echo base_url('Home/')?>">Home</a></li>
						<li class="breadcrumb-item active"><a href="<?php echo base_url('Home/donors')?>">Members</a></li>
						<li class="breadcrumb-item active">Message Detail</li>
					</ol>
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-primary card-outline">
						<div class="card-header">
							<h3 class="card-title">Donor Detail </h3>

							<div class="card-tools">
								<div class="btn-group">
									<a href="<?php echo base_url('Home/donors')?>" class="btn btn-default btn-sm" data-toggle="tooltip" title="Previous"><i class="fas fa-chevron-left"></i></a>
									<a onclick="return confirm('Are you sure to delete This record?');" href="<?php echo base_url('Home/donor_delete/'.$donor_detail->id);?>" class="btn btn-default btn-sm" data-toggle="tooltip" data-container="body" title="Delete">
										<i class="far fa-trash-alt"></i>
									</a>

								</div>
								<!-- /.btn-group -->

							</div>
						</div>
						<!-- /.card-header -->
						<div class="card-body p-0">
							<div class="mailbox-read-message">
								<div class="table-responsive">
									<table class="table table-hover table-bordered">
										<tr>
											<td>Name:</td>
											<td><?php echo $donor_detail->first_name." ".$donor_detail->last_name;?></td>
										</tr>
										<tr>
											<td>Email:</td>
											<td><?php echo $donor_detail->email;?></td>
										</tr>
										<tr>
											<td>Address:</td>
											<td><?php echo $donor_detail->address;?></td>
										</tr>
										<tr>
											<td>Contact:</td>
											<td><?php echo $donor_detail->contact_no;?></td>
										</tr>
										<tr>
											<td>Blood Group:</td>
											<td><?php echo $donor_detail->blood_group;?></td>
										</tr>
										<tr>
											<td>Date of Birth:</td>
											<td><?php echo $donor_detail->dob;?></td>
										</tr>
										<tr>
											<td>Preference:</td>
											<td><?php echo $donor_detail->type;?></td>
										</tr>
										<tr>
											<td>Last Donated:</td>
											<td><?php echo $donor_detail->last_donated;?></td>
										</tr>
										<tr>
											<td>Registered on:</td>
											<td><?php echo $donor_detail->created_at;?></td>
										</tr>
										<tr>
											<td>Last Updated:</td>
											<td><?php if($donor_detail->updated_at){echo $donor_detail->updated_at;}else{echo 'Never';}?></td>
										</tr>
									</table>
								</div>
							</div>
							<!-- /.mailbox-read-message -->
						</div>
						<!-- /.card-body -->
						<div class="card-footer">

						</div>
						<!-- /.card-footer -->
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
