<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$this->load->view('admin/auth/login');
	}
	public function authenticate_user()
	{
		if($this->session->userdata('fname')){
			redirect('Home/index');
		}
		$config = array(
			array(
				'field' => 'email',
				'label' => 'Email',
				'rules' => 'valid_email|required|trim',
				'errors' => array(
					'required' => 'You must provide an %s.',
					'valid_email'=>'Your %s seems invalid'
				),
			),
			array(
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'required|trim',
				'errors' => array(
					'required' => 'You must provide a %s.',
				),
			)
		);
		$this->form_validation->set_rules($config);
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('admin/auth/login');
		}else{
			$email = $this->security->xss_clean($this->input->post('email'));
			$password = $this->security->xss_clean($this->input->post('password'));
			$remember = $this->input->post('remember');
			$this->load->model('admin/Users', 'Users');
			$user = $this->Users->login($email, $password);
			if($user)
			{
				$userdata = array(
					'fname'=>$user->fname,
					'lname'=>$user->lname
				);
				$this->session->set_userdata($userdata);
				redirect('Home/index');
			}else{
				$this->session->set_flashdata('message', 'Email or Password is incorrect');
				$this->load->view('admin/auth/login');
			}
		}
	}


	public function logout()
	{
		$this->session->unset_userdata('fname');
		$this->session->unset_userdata('lname');
		redirect('Login/index');
	}
}

