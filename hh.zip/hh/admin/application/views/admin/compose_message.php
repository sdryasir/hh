<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-sm-6">
					<h1><?php echo $title; ?></h1>
				</div>
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="<?php echo base_url('Home/') ?>">Home</a></li>
						<li class="breadcrumb-item active"><a
								href="<?php echo base_url('Home/messages') ?>">Messages</a></li>
						<li class="breadcrumb-item active">Message Detail</li>
					</ol>
				</div>
			</div>
		</div><!-- /.container-fluid -->
	</section>

	<!-- Main content -->
	<section class="content">
		<div class="container-fluid">
			<?php if($this->session->flashdata('email_message')){?>
				<div class="alert">
					<?php echo $this->session->flashdata('email_message');?>
				</div>
			<?php }?>
			<div class="row">
				<div class="col-md-12">
					<div class="card card-primary card-outline">
						<?php echo form_open('Home/send_reply')?>
						<div class="card-header">
							<a href="<?php echo base_url('Home/messages')?>" class="btn btn-default"><i class="fas fa-times"></i> Discard</a>
							<button type="submit" class="btn btn-primary"><i class="far fa-envelope"></i> Send</button>
						</div>
						<!-- /.card-header -->
						<!-- /.card-header -->
						<div class="card-body">
							<div class="form-group">
								<small class="error"><?php echo form_error('email')?></small>
								<input class="form-control" required name="email" value="<?php echo $message->email;?>" readonly
									   placeholder="To:">
								<input type="hidden" name="id" value="<?php echo $message->id;?>">
							</div>
							<div class="form-group">
								<small class="error"><?php echo form_error('subject')?></small>
								<input required class="form-control" name="subject" placeholder="Subject:">
							</div>
							<div class="form-group">
								<small class="error"><?php echo form_error('message_body')?></small>
								<textarea required="required" id="compose-textarea" name="message_body" class="form-control" rows="6" style="height: 400px">

								</textarea>
							</div>
						</div>
						<!-- /.card-body -->
						<?php form_close();?>
					</div>
					<!-- /.card -->
				</div>
				<!-- /.col -->
			</div>
			<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->
