<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Donation_model extends CI_Model {
	public function doners()
	{
		$query = $this->db->get('tbl_donor');
		return $query ? $query->result():false;
	}
	public function messages()
	{
		$query = $this->db->get('tbl_contact');
		return $query ? $query->result():false;
	}
	public function donor_history($id)
	{
		$this->db->where('donor_id',$id);
		$query = $this->db->get('tbl_donation_history');
		return $query ? $query->result():false;
	}
	public function message_detail($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('tbl_contact');
		return $query ? $query->row():false;
	}
	public function reply_status_update($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->update('tbl_contact',array('status'=>1));
		return $query ? true:false;
	}
	public function message_delete($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->delete('tbl_contact');
		return $query ? true:false;
	}
	public function delete_history($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->delete('tbl_donation_history');
		return $query ? true:false;
	}
	public function donor_detail($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('tbl_donor');
		return $query ? $query->row():false;
	}
	public function donor_delete($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->delete('tbl_donor');
		return $query ? true:false;
	}

	public function count_doners()
	{
		$this->db->where('type','donor');
		$query = $this->db->get('tbl_donor');
		return $query ? $query->num_rows():false;
	}
	public function count_accepters()
	{
		$this->db->where('type','accepter');
		$query = $this->db->get('tbl_donor');
		return $query ? $query->num_rows():false;
	}
	public function count_messages()
	{
		$this->db->where('status',0);
		$query = $this->db->get('tbl_contact');
		return $query ? $query->num_rows():false;
	}

}
