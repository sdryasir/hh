<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Model
{
	/*test user
	Email: sdr.yasir@gmail.com
	Password: admin
	*/
	public function login($email, $password){
		$this->db->where(array('email'=>$email, 'status'=>1));
		$query = $this->db->get('admin_tbl');
		if($query->num_rows() == 1){
			$row = $query->row();
			if(password_verify($password, $row->password)){
				return $row;
			}
		}
		return false;
	}
	public function email_exists($email)
	{
		$this->db->where(array('email'=>$email, 'status'=>1));
		$query = $this->db->get('admin_tbl');
		$row = $query->row();
		return ($query->num_rows()===1 && $row->email) ? $row->first_name : false;
	}
	public function verify_reset_password_code($email, $email_code)
	{
		$this->db->where(array('email'=>$email, 'status'=>1));
		$query = $this->db->get('admin_tbl');
		$row = $query->row();
		if($query->num_rows()===1){
			return ($code = md5($this->config->item('salt').$row->first_name)) ? true :false;
		}else{
			return false;
		}
	}
	public function update_password()
	{
		$email = $this->input->post('email');
		$password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
		$data = array(
			'password' => $password
		);
		$this->db->where(array('email'=>$email));
		$this->db->update('admin_tbl', $data);
		if($this->db->affected_rows() === 1)
		{
			return true;
		}else{
			return false;
		}
	}


	public function listusers()
	{
		$query = $this->db->get('users');
		if($query)
		{
			return $query->result();
		}else{
			return false;
		}
	}
	public function create_user($post)
	{
		if($this->db->insert('users', $post))
		{
			return true;
		}else{
			return false;
		}
	}
	public function edit_user($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->get('users');
		if($query)
		{
			return $query->result();
		}else{
			return false;
		}
	}
	public function update_user($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->get('users');
		if($query)
		{
			return $query->result();
		}else{
			return false;
		}
	}
	public function delete_user($id)
	{
		$this->db->where('id', $id);
		$query = $this->db->delete('users');
		if($query)
		{
			return true;
		}else{
			return false;
		}
	}
}
